"use client";

import Link from "next/link";
import { useCallback, useEffect, useRef, useState } from "react";

import { useActiveWallet, useWallets } from "@privy-io/react-auth";
import { BrandLockup } from "@/components/home-terminal";
import { usePrivyRuntime } from "@/components/privy-provider";
import { useWalletState } from "@/components/wallet-connect-button";
import { runManualExecutionFlow } from "@/lib/manual-execution";

import type {
  BlotterData,
  OnboardingProfile,
  OnboardingQuestion,
  PromotedManifest,
  PublicStrategyCardData,
  QualificationFlowResult,
  StrategyRecommendation,
} from "@/lib/contracts";
import {
  getRecommendationExplanationBundle,
  isDirectionalPreviewOnly,
} from "@/lib/portfolio-ui";
import { formatCurrency, formatPercent, getWorkspaceSpotlightData } from "@/lib/data-source";
import { getAssetDescription, getAssetHref, getCleanRationale } from "@/lib/holdings-display";

function humanizeState(state: string): string {
  const map: Record<string, string> = {
    active: "Active",
    paused: "Paused",
    watch: "Monitoring",
    view_ready: "Ready to view",
    blocked: "Blocked",
    funding_required: "Needs funding",
    connect_required: "Connect wallet",
    activation_ready: "Ready",
    explore: "Exploring",
    settled: "Settled",
    pending: "Pending",
  };
  return map[state] ?? state.replaceAll("_", " ");
}

function stateTooltip(state: string): string {
  const tips: Record<string, string> = {
    active: "This position is live and tracking the portfolio strategy.",
    paused: "This position is temporarily paused. No trades will execute until resumed.",
    watch: "This position is being monitored for potential changes.",
    view_ready: "Your portfolio preview is ready. Review it before funding.",
    blocked: "Action required before this position can proceed.",
    funding_required: "Deposit USDC to activate this portfolio.",
    connect_required: "Connect your wallet to continue.",
    activation_ready: "Everything is set. Ready to activate.",
    explore: "Exploring potential portfolio configurations.",
    settled: "This trade has been completed and settled on-chain.",
    pending: "Waiting for confirmation or processing.",
  };
  return tips[state] ?? "";
}

const HIDDEN_OPTION_IDS = new Set(["unsure", "unset"]);
const SKIP_OPTION_PRIORITY = ["unsure", "unset", "default_requested"] as const;

function getVisibleQuestionOptions(question: OnboardingQuestion) {
  const visibleOptions = question.options.filter((option) => !HIDDEN_OPTION_IDS.has(option.id));
  return visibleOptions.length > 0 ? visibleOptions : question.options;
}

function getSkipQuestionOption(question: OnboardingQuestion) {
  for (const optionId of SKIP_OPTION_PRIORITY) {
    const option = question.options.find((candidate) => candidate.id === optionId);
    if (option) {
      return option;
    }
  }

  return null;
}

export function OnboardingQuestionFlow({
  answers,
  onAnswer,
  onBack,
  onReset,
  onFastPath,
  questions,
  recommendation,
  allAnswered,
  recommendedManifest,
  qualification,
  blotter,
  previewStatus,
}: {
  answers: Record<string, string>;
  onAnswer: (questionId: string, optionId: string) => void;
  onBack: () => void;
  onReset: () => void;
  onFastPath?: () => void;
  questions: OnboardingQuestion[];
  profile: OnboardingProfile;
  recommendation: StrategyRecommendation;
  allAnswered: boolean;
  recommendedManifest: PromotedManifest;
  recommendedStrategy: PublicStrategyCardData;
  qualification: QualificationFlowResult;
  blotter?: BlotterData;
  previewStatus?: {
    tone: "loading" | "error";
    message: string;
    onRetry?: () => void;
  } | null;
}) {
  const [optionCooldown, setOptionCooldown] = useState(false);
  const primaryQuestions = questions.filter((q) => !q.conditional);
  const answeredPrimaryCount = primaryQuestions.filter((q) => answers[q.id] !== undefined).length;

  // Guard: if no questions are loaded, show a fallback instead of crashing
  if (primaryQuestions.length === 0) {
    return (
      <div className="onboarding-flow-wrapper">
        <div className="onboarding-flow">
          <p className="panel-note" style={{ textAlign: "center", padding: "40px 16px" }}>
            No questions available. Please try refreshing the page.
          </p>
          <div className="onboarding-back-row">
            <button className="button button-ghost" onClick={onReset} type="button">Start over</button>
          </div>
        </div>
      </div>
    );
  }

  if (allAnswered) {
    return (
      <PostQuestionnaireWorkspace
        recommendation={recommendation}
        manifest={recommendedManifest}
        qualification={qualification}
        blotter={blotter}
        onReset={onReset}
        previewStatus={previewStatus}
      />
    );
  }

  const currentPrimary = primaryQuestions.find((q) => answers[q.id] === undefined);
  if (!currentPrimary) return null;

  const previousPrimaryIndex = primaryQuestions.indexOf(currentPrimary) - 1;
  const previousPrimary = previousPrimaryIndex >= 0 ? primaryQuestions[previousPrimaryIndex] : null;
  const previousAnswer = previousPrimary ? answers[previousPrimary.id] : undefined;

  const pendingConditional = previousPrimary ? questions.find(
    (q) =>
      q.conditional &&
      q.triggeredByQuestionId === previousPrimary.id &&
      q.triggeredByOptionIds?.includes(previousAnswer ?? "") &&
      answers[q.id] === undefined,
  ) : null;

  const questionToShow = pendingConditional ?? currentPrimary;
  const isPrimary = !questionToShow.conditional;
  const displayStep = isPrimary ? answeredPrimaryCount + 1 : answeredPrimaryCount;
  const visibleOptions = getVisibleQuestionOptions(questionToShow);
  const skipOption = getSkipQuestionOption(questionToShow);

  return (
    <div className="onboarding-flow-wrapper">
    <div className="onboarding-flow">
      <div className="onboarding-progress">
        <div className="onboarding-progress-meta">
          <span className="section-kicker">
            {displayStep} of {primaryQuestions.length}
          </span>
          {onFastPath && (
            <button className="ob-skip-btn" onClick={onFastPath} type="button">
              Skip — pick for me
            </button>
          )}
        </div>
        <div className="progress-track">
          <span style={{ width: `${(answeredPrimaryCount / primaryQuestions.length) * 100}%` }} />
        </div>
      </div>

      <div className="onboarding-flow-question">
        <div className="onboarding-question-head">
          <div>
            <h2>{questionToShow.prompt}</h2>
            <p>{questionToShow.helper}</p>
          </div>
        </div>
        <div className="onboarding-option-grid">
          {visibleOptions.map((option) => (
            <button
              className="onboarding-option"
              key={option.id}
              onClick={() => {
                if (optionCooldown) return;
                setOptionCooldown(true);
                onAnswer(questionToShow.id, option.id);
                setTimeout(() => setOptionCooldown(false), 600);
              }}
              type="button"
            >
              <strong>{option.label}</strong>
              <span>{option.description}</span>
            </button>
          ))}
        </div>
        {skipOption && (
          <button
            className="onboarding-option onboarding-option-skip"
            onClick={() => {
              if (optionCooldown) return;
              setOptionCooldown(true);
              onAnswer(questionToShow.id, skipOption.id);
              setTimeout(() => setOptionCooldown(false), 600);
            }}
            type="button"
          >
            <strong>Skip / not sure</strong>
            <span>We will pick sensible defaults for you.</span>
          </button>
        )}
      </div>

      <div className="onboarding-back-row">
        <button className="button button-ghost" onClick={onBack} type="button">Back</button>
        <button className="button button-ghost" onClick={onReset} type="button">Start over</button>
      </div>
    </div>
    </div>
  );
}

/* ────────────────────────────────────────────────────────
   Post-questionnaire workspace
   ──────────────────────────────────────────────────────── */

const tourSteps = [
  { id: "welcome", label: "Portfolio summary", caption: "Your matched portfolio with simulated replay performance", anchor: "pq-summary" },
  { id: "holdings", label: "Holdings", caption: "The specific assets and weights in your portfolio", anchor: "pq-holdings" },
  { id: "intelligence", label: "Market signals", caption: "What is driving the portfolio right now and recent changes", anchor: "pq-rail" },
  { id: "activity", label: "Activity", caption: "Simulated positions and events. Real after you deposit.", anchor: "pq-activity-section" },
  { id: "activate", label: "Deposit", caption: "Choose a USDC notional when you are ready, then fund your wallet to activate.", anchor: "pq-deposit-cta" },
];

function buildChartPath(values: number[]) {
  const min = Math.min(...values);
  const max = Math.max(...values);
  const range = max - min || 1;
  return values
    .map((value, index) => {
      const x = (index / Math.max(values.length - 1, 1)) * 100;
      const y = 100 - ((value - min) / range) * 100;
      return `${index === 0 ? "M" : "L"} ${x.toFixed(2)} ${y.toFixed(2)}`;
    })
    .join(" ");
}

function PostQuestionnaireWorkspace({
  recommendation,
  manifest,
  qualification,
  blotter,
  onReset,
  previewStatus,
}: {
  recommendation: StrategyRecommendation;
  manifest: PromotedManifest;
  qualification: QualificationFlowResult;
  blotter?: BlotterData;
  onReset: () => void;
  previewStatus?: {
    tone: "loading" | "error";
    message: string;
    onRetry?: () => void;
  } | null;
}) {
  const [phase, setPhase] = useState<"analysis" | "gate" | "workspace">("analysis");
  const [tourStep, setTourStep] = useState(0);
  const [tourDismissed, setTourDismissed] = useState(false);

  const bundle = getRecommendationExplanationBundle(manifest);
  const directionalPreviewOnly = isDirectionalPreviewOnly(manifest);

  if (phase === "analysis") {
    return (
      <AnalysisTransition
        recommendation={recommendation}
        manifest={manifest}
        onComplete={() => setPhase("gate")}
      />
    );
  }

  if (phase === "gate") {
    return (
      <RecommendationGate
        recommendation={recommendation}
        qualification={qualification}
        manifest={manifest}
        bundle={bundle}
        directionalPreviewOnly={directionalPreviewOnly}
        onEnterWorkspace={() => setPhase("workspace")}
        onReset={onReset}
        previewStatus={previewStatus}
      />
    );
  }

  return (
    <SimulatedWorkspace
      manifest={manifest}
      blotter={blotter}
      directionalPreviewOnly={directionalPreviewOnly}
      recommendation={recommendation}
      qualification={qualification}
      onReset={onReset}
      tourStep={tourStep}
      tourDismissed={tourDismissed}
      onTourNext={() => {
        if (tourStep < tourSteps.length - 1) setTourStep(tourStep + 1);
        else setTourDismissed(true);
      }}
      onTourPrev={() => {
        if (tourStep > 0) setTourStep(tourStep - 1);
      }}
      onTourDismiss={() => setTourDismissed(true)}
      previewStatus={previewStatus}
    />
  );
}

/* ── Analysis Transition — profile-aware staged progress ── */

function AnalysisTransition({
  recommendation,
  manifest,
  onComplete,
}: {
  recommendation: StrategyRecommendation;
  manifest: PromotedManifest;
  onComplete: () => void;
}) {
  const [activeStep, setActiveStep] = useState(0);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const prefersReducedMotion = useRef(false);

  // Profile inputs that drove the match — shown alongside progress
  const profileInputs = [
    { label: "Risk", value: recommendation.risk_band },
    { label: "Stance", value: recommendation.stance.replaceAll("_", " ") },
    { label: "Activity", value: recommendation.activity_level },
    { label: "Rebalance", value: recommendation.rebalance_cadence.replaceAll("_", " ") },
  ];

  const steps = [
    { label: "Analyzing profile", detail: `${recommendation.risk_band} risk · ${recommendation.stance.replaceAll("_", " ")}` },
    { label: "Comparing candidates", detail: `${manifest.allocations.length} holdings · ${manifest.frontend.risk_label} risk` },
    { label: "Checking risk fit", detail: `Max drawdown ${formatPercent(manifest.replay.maxDrawdownPct)}` },
    { label: "Building match", detail: recommendation.title },
    { label: "Preparing preview", detail: `${formatPercent(manifest.replay.netReturnPct)} simulated return` },
  ];

  useEffect(() => {
    prefersReducedMotion.current = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (prefersReducedMotion.current) { onComplete(); return; }

    const durations = [2500, 2500, 2500, 2000, 2000];
    let step = 0;
    function advance() {
      step++;
      if (step >= steps.length) { timerRef.current = setTimeout(onComplete, 600); return; }
      setActiveStep(step);
      timerRef.current = setTimeout(advance, durations[step]);
    }
    timerRef.current = setTimeout(advance, durations[0]);
    return () => { if (timerRef.current) clearTimeout(timerRef.current); };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const current = steps[activeStep];
  const progress = ((activeStep + 1) / steps.length) * 100;

  return (
    <div className="analysis-screen">
      <div className="analysis-inner">
        <span className="landing-kicker">Evaluating fit · Autoresearch</span>
        <h1 className="analysis-title">{current.label}</h1>
        <p className="analysis-detail">{current.detail}</p>

        <div className="analysis-progress-track">
          <div className="analysis-progress-fill" style={{ width: `${progress}%` }} />
        </div>

        {/* Profile inputs card — shows what drove the match */}
        <div className="analysis-profile-card">
          <span className="section-kicker">Your profile</span>
          <div className="analysis-profile-grid">
            {profileInputs.map((input) => (
              <div className="analysis-profile-item" key={input.label}>
                <span>{input.label}</span>
                <strong>{input.value}</strong>
              </div>
            ))}
          </div>
        </div>

        <div className="analysis-steps">
          {steps.map((s, i) => (
            <div className={`analysis-step ${i < activeStep ? "analysis-step-done" : ""} ${i === activeStep ? "analysis-step-active" : ""}`} key={s.label}>
              <span className="analysis-step-dot" />
              <span>{s.label}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ── Recommendation Gate — with "Why this fits" section ── */

function RecommendationGate({
  recommendation,
  qualification,
  manifest,
  bundle,
  directionalPreviewOnly,
  onEnterWorkspace,
  onReset,
  previewStatus,
}: {
  recommendation: StrategyRecommendation;
  qualification: QualificationFlowResult;
  manifest: PromotedManifest;
  bundle: ReturnType<typeof getRecommendationExplanationBundle>;
  directionalPreviewOnly: boolean;
  onEnterWorkspace: () => void;
  onReset: () => void;
  previewStatus?: { tone: "loading" | "error"; message: string; onRetry?: () => void; } | null;
}) {
  const spotlight = getWorkspaceSpotlightData(manifest);
  const values = spotlight.points.map((p) => p.value);
  const path = buildChartPath(values);
  const keyDrivers = qualification.whyRecommended.slice(0, 2);
  const fitNotes = qualification.fitNotes.slice(0, 1);
  const leadComponents = bundle.components.slice(0, 4);
  const [gateChartHover, setGateChartHover] = useState<{ x: number; value: number } | null>(null);

  return (
    <div className="pq-gate">
      <div className="pq-gate-inner">
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: "16px" }}>
          <span className="landing-kicker">Your portfolio is ready</span>
          <button className="button button-primary button-lg" onClick={onEnterWorkspace} type="button">
            See my portfolio
          </button>
        </div>
        <span className="hover-card-trigger token-pill" style={{ cursor: "help" }}>
          <span className="hover-card">
            <strong className="hover-card-title">Autoresearch</strong>
            {qualification.optimizationMethod.details.map((d, i) => (
              <p key={i}>{d}</p>
            ))}
          </span>
          {qualification.optimizationMethod.pillLabel}
        </span>
        <h1 className="pq-gate-title">{recommendation.title}</h1>
        <p className="pq-gate-sub">{qualification.summary}</p>

        {/* Mini replay chart with hover */}
        <div
          className="pq-gate-chart"
          style={{ position: "relative", cursor: "crosshair" }}
          onMouseMove={(e) => {
            const rect = e.currentTarget.getBoundingClientRect();
            const xPct = (e.clientX - rect.left) / rect.width;
            const idx = Math.min(Math.round(xPct * (values.length - 1)), values.length - 1);
            setGateChartHover({ x: xPct * 100, value: values[idx] });
          }}
          onMouseLeave={() => setGateChartHover(null)}
        >
          <svg viewBox="0 0 100 100" preserveAspectRatio="none">
            <defs>
              <linearGradient id="gateLine" x1="0%" x2="100%" y1="0%" y2="0%">
                <stop offset="0%" stopColor="#ff1800" />
                <stop offset="100%" stopColor="#0a0a0a" />
              </linearGradient>
            </defs>
            <path className="workspace-chart-fill" d={`${path} L 100 100 L 0 100 Z`} />
            <path className="workspace-chart-line" d={path} style={{ stroke: "url(#gateLine)" }} />
          </svg>
          {gateChartHover && (
            <div className="pq-chart-cursor" style={{ left: `${gateChartHover.x}%` }} />
          )}
          {gateChartHover && (
            <div className="pq-chart-hover-label" style={{ left: `${gateChartHover.x}%` }}>
              {formatCurrency(gateChartHover.value)}
            </div>
          )}
        </div>

        {/* Stat chips */}
        <div className="pq-gate-stats">
          <div className="pq-gate-stat">
            <span>30-day return</span>
            <strong>
              {gateChartHover
                ? formatPercent(((gateChartHover.value - manifest.replay.startingCapital) / manifest.replay.startingCapital) * 100)
                : formatPercent(manifest.replay.netReturnPct)}
            </strong>
          </div>
          <div className="pq-gate-stat">
            <span>Max drawdown</span>
            <strong>{formatPercent(manifest.replay.maxDrawdownPct)}</strong>
          </div>
          <div className="pq-gate-stat">
            <span>Holdings</span>
            <strong>{manifest.allocations.length}</strong>
          </div>
          <div className="pq-gate-stat">
            <span>Risk</span>
            <strong>{manifest.frontend.risk_label}</strong>
          </div>
        </div>

        {/* Why this fits you — profile-to-portfolio mapping */}
        <div className="pq-gate-fit">
          <span className="section-kicker">Why this fits you</span>
          <div className="pq-gate-fit-grid">
            <div className="pq-gate-fit-item">
              <span>You chose</span>
              <strong>{recommendation.risk_band} risk</strong>
            </div>
            <div className="pq-gate-fit-item">
              <span>Portfolio is</span>
              <strong>{manifest.frontend.risk_label} risk · {manifest.allocations.length} names</strong>
            </div>
            <div className="pq-gate-fit-item">
              <span>Rebalance</span>
              <strong>{recommendation.rebalance_cadence.replaceAll("_", " ")}</strong>
            </div>
            <div className="pq-gate-fit-item">
              <span>Stance</span>
              <strong>{recommendation.stance.replaceAll("_", " ")}</strong>
            </div>
          </div>
        </div>

        <div className="pq-gate-explain-grid">
          <article className="panel-card panel-card-subtle pq-gate-panel">
            <span className="section-kicker">Why this fits you</span>
            <div className="pq-gate-list">
              {keyDrivers.map((reason) => (
                <div className="pq-gate-list-item" key={reason}>
                  <strong>{reason}</strong>
                </div>
              ))}
              {fitNotes.map((note) => (
                <p className="panel-note" key={note}>{note}</p>
              ))}
            </div>
          </article>

          <article className="panel-card panel-card-subtle pq-gate-panel">
            <span className="section-kicker">What changes next</span>
            <div className="info-stack">
              <div>
                <span>How it changes</span>
                <strong>{bundle.howItChanges}</strong>
              </div>
              <div>
                <span>Next rebalance trigger</span>
                <strong>{bundle.whatWouldTriggerNextRebalance}</strong>
              </div>
              <div>
                <span>Who this is best for</span>
                <strong>{bundle.bestFor}</strong>
              </div>
            </div>
          </article>
        </div>

        <div className="pq-gate-holdings">
          {leadComponents.map((component) => (
            <div className="pq-gate-holding" key={component.componentId} title={getAssetDescription(component.title) ?? getCleanRationale(undefined, component.sleeve)}>
              <strong>{component.title}</strong>
              <span>{getCleanRationale(undefined, component.sleeve)}</span>
            </div>
          ))}
        </div>

        {/* Policy chips — use actual holdings count from manifest */}
        <div className="pq-gate-chips">
          {recommendation.behavior_chips.slice(0, 4).map((chip, i) => {
            const displayChip = i === 0
              ? `${manifest.allocations.length} holdings`
              : chip;
            return <span className="token-pill" key={chip}>{displayChip}</span>;
          })}
        </div>

        <div className="pq-gate-method">
          <span className="section-kicker">{qualification.optimizationMethod.label}</span>
          <div className="pq-gate-method-trigger" tabIndex={0}>
            <span className="token-pill pq-gate-method-pill">
              {qualification.optimizationMethod.pillLabel}
            </span>
            <div className="pq-gate-method-tooltip">
              <strong>{qualification.optimizationMethod.summary}</strong>
              <div className="pq-gate-method-tooltip-list">
                {qualification.optimizationMethod.details.map((detail) => (
                  <p key={detail}>{detail}</p>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="pq-gate-cta">
          <button className="button button-primary button-xl" onClick={onEnterWorkspace} type="button">
            See my portfolio
          </button>
          <button className="button button-ghost" onClick={onReset} type="button">
            Change answers
          </button>
        </div>

        <p className="pq-gate-note">
          {directionalPreviewOnly ? "Preview only. Self-custody." : "Simulation. No money moves until you deposit."}
        </p>
        <p className="pq-gate-note">{bundle.howToReadReplay.replace(/basket\.\w+/g, "the benchmark").replace(/\b\d+\.\d{2}%/g, (m) => m).replace(/_/g, " ")}</p>
        {previewStatus ? <p className="pq-gate-note">{previewStatus.message}</p> : null}
      </div>
    </div>
  );
}

/* ── Simulated Workspace — with performance surface + improved tour ── */

function SimulatedWorkspace({
  manifest,
  blotter,
  directionalPreviewOnly,
  recommendation,
  qualification,
  onReset,
  tourStep,
  tourDismissed,
  onTourNext,
  onTourPrev,
  onTourDismiss,
  previewStatus,
}: {
  manifest: PromotedManifest;
  blotter?: BlotterData;
  directionalPreviewOnly: boolean;
  recommendation: StrategyRecommendation;
  qualification: QualificationFlowResult;
  onReset: () => void;
  tourStep: number;
  tourDismissed: boolean;
  onTourNext: () => void;
  onTourPrev: () => void;
  onTourDismiss: () => void;
  previewStatus?: { tone: "loading" | "error"; message: string; onRetry?: () => void; } | null;
}) {
  const { enabled: privyEnabled, login, authenticated, user, logout, getAccessToken, getIdentityToken } =
    usePrivyRuntime();
  const walletAddress = authenticated ? user?.wallet?.address : null;
  const shortWallet = walletAddress
    ? `${walletAddress.slice(0, 6)}...${walletAddress.slice(-4)}`
    : null;
  const [buyModalOpen, setBuyModalOpen] = useState(false);
  const [buyAmount, setBuyAmount] = useState("100");
  const [buyStatus, setBuyStatus] = useState<string | null>(null);
  const [buyRunning, setBuyRunning] = useState(false);
  const walletState = useWalletState();
  const { wallets } = useWallets();
  const { wallet: activeWallet } = useActiveWallet();
  const activeConnectedWallet = activeWallet && "getEthereumProvider" in activeWallet
    ? (activeWallet as (typeof wallets)[number])
    : null;

  const closeBuyModal = useCallback(() => setBuyModalOpen(false), []);

  // Escape key closes the buy modal
  useEffect(() => {
    if (!buyModalOpen) return;
    function handleKeyDown(e: KeyboardEvent) {
      if (e.key === "Escape") closeBuyModal();
    }
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [buyModalOpen, closeBuyModal]);

  function parseBuyAmount(): number {
    const parsed = parseFloat(buyAmount);
    if (!Number.isFinite(parsed) || parsed <= 0) return 0;
    return parsed;
  }

  async function handleBuy() {
    if (buyRunning) return;

    // Prompt wallet connection if not authenticated
    if (!authenticated) {
      login();
      return;
    }

    const notionalUsd = parseBuyAmount();
    if (notionalUsd <= 0) {
      setBuyStatus("Enter a valid USDC amount greater than zero.");
      return;
    }

    if (!walletState.connected || !walletState.walletAddress) {
      setBuyStatus("Connecting wallet...");
      login();
      return;
    }

    setBuyRunning(true);
    setBuyStatus("Getting authorization...");
    try {
      const [accessToken, identityToken] = await Promise.all([
        getAccessToken(),
        getIdentityToken(),
      ]);

      setBuyStatus("Starting execution...");
      const result = await runManualExecutionFlow({
        manifest,
        requestedNotionalUsd: notionalUsd,
        initiationAction: "create",
        latestActivation: null,
        existingExecutionRequest: null,
        auth: { accessToken, identityToken },
        wallets,
        activeWallet: activeConnectedWallet,
        walletState: {
          connected: walletState.connected,
          walletAddress: walletState.walletAddress,
          embeddedWallet: walletState.embeddedWallet ?? { status: "not-created", address: null },
          smartAccount: walletState.smartAccount ?? { status: "not-created", address: null },
        },
        onStatus: (status) => setBuyStatus(status.message),
      });
      if (result.blocker) {
        setBuyStatus(result.blocker);
      } else {
        setBuyStatus("Execution submitted successfully!");
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : "An unexpected error occurred.";
      // Classify common failure modes for user-friendly messages
      if (message.toLowerCase().includes("user rejected") || message.toLowerCase().includes("user denied")) {
        setBuyStatus("Signature rejected. You can try again when ready.");
      } else if (message.toLowerCase().includes("network") || message.toLowerCase().includes("fetch")) {
        setBuyStatus("Unable to reach the server. Check your connection and try again.");
      } else {
        setBuyStatus(message);
      }
    } finally {
      setBuyRunning(false);
    }
  }
  const spotlight = getWorkspaceSpotlightData(manifest, blotter);
  const values = spotlight.points.map((p) => p.value);
  const path = buildChartPath(values);
  const mi = manifest.market_intelligence;
  const positions = blotter?.positions ?? [];
  const activity = blotter?.activity ?? [];
  const currentTour = tourDismissed ? null : tourSteps[tourStep];
  const highlightId = currentTour?.anchor ?? null;
  const [chartHover, setChartHover] = useState<{ x: number; value: number } | null>(null);
  const [tourWelcomeShown, setTourWelcomeShown] = useState(false);
  const bundle = getRecommendationExplanationBundle(manifest);
  const activationLabel = privyEnabled
    ? directionalPreviewOnly
      ? "Review preview"
      : "Start deposit"
    : "Wallet connect unavailable";

  // Scroll highlighted section into view when tour advances
  useEffect(() => {
    if (!highlightId) return;
    const el = document.getElementById(highlightId);
    if (el) {
      if (highlightId === "pq-rail") {
        window.scrollTo({ top: 0, behavior: "smooth" });
      } else {
        el.scrollIntoView({ behavior: "smooth", block: "center" });
      }
    }
  }, [highlightId]);

  // Shareable portfolio URL — short ID derived from slug
  useEffect(() => {
    const shortId = manifest.slug.split("-").map(w => w[0]).join("").toUpperCase() + manifest.slug.length;
    const url = new URL(window.location.href);
    url.searchParams.set("p", shortId);
    window.history.replaceState({}, "", url.toString());
  }, [manifest.slug]);

  return (
    <>
    {!tourDismissed && !tourWelcomeShown && (
      <div className="pq-tour-welcome-overlay" role="dialog" aria-modal="true" aria-label="Portfolio tour">
        <div className="pq-tour-welcome-card">
          <h2>Take a quick tour?</h2>
          <p>We will walk you through your portfolio, holdings, and market signals.</p>
          <div style={{ display: "flex", gap: "12px", justifyContent: "center" }}>
            <button className="button button-primary button-lg" onClick={() => setTourWelcomeShown(true)} type="button" autoFocus>Start tour</button>
            <button className="button button-ghost button-lg" onClick={() => { setTourWelcomeShown(true); onTourDismiss(); }} type="button">Skip</button>
          </div>
        </div>
      </div>
    )}
    <div className={`pq-workspace ${currentTour ? "pq-workspace-touring" : ""}`}>
      {/* ── Preview bar with big deposit CTA ── */}
      <div className="pq-preview-bar">
        <div className="pq-preview-bar-left">
          <Link href="/" style={{ display: "flex", alignItems: "center", padding: "0 18px", background: "var(--black)", marginLeft: "-24px", marginTop: "-10px", marginBottom: "-10px", alignSelf: "stretch" }}>
            <BrandLockup size="sm" />
          </Link>
          <span className="preview-chip">Simulation</span>
          <span>Preview. No money has moved.</span>
        </div>
        <div className="pq-preview-bar-actions">
          {authenticated ? (
            <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
              <button className="button button-primary button-lg" onClick={() => setBuyModalOpen(true)} type="button">
                Buy with 1inch
              </button>
              <span style={{ padding: "4px 12px", background: "var(--black)", color: "var(--positive)", border: "2px solid var(--positive)", fontFamily: "var(--font-mono)", fontSize: "0.82rem", fontWeight: 700, letterSpacing: "0.04em" }}>{shortWallet}</span>
              <button className="button button-ghost button-sm" onClick={logout} type="button">Disconnect</button>
            </div>
          ) : (
            <button
              className="button button-primary button-lg"
              disabled={!privyEnabled}
              id="pq-deposit-cta"
              onClick={privyEnabled ? login : undefined}
              type="button"
            >
              {activationLabel}
            </button>
          )}
          <button className="button button-ghost button-sm" onClick={onReset} type="button">
            Start over
          </button>
        </div>
      </div>

      {/* ── Component-anchored tour with captions ── */}
      {currentTour && (
        <div className="pq-tour-bar">
          <div className="pq-tour-bar-inner">
            <div className="pq-tour-progress">
              {tourSteps.map((_, i) => (
                <span className={`pq-tour-dot ${i === tourStep ? "pq-tour-dot-active" : ""} ${i < tourStep ? "pq-tour-dot-done" : ""}`} key={i} />
              ))}
            </div>
            <div className="pq-tour-text">
              <span className="pq-tour-label">{currentTour.label}</span>
              <span className="pq-tour-caption">{currentTour.caption}</span>
            </div>
            <div className="pq-tour-actions">
              {tourStep > 0 && (
                <button className="button button-ghost button-sm" onClick={onTourPrev} type="button">Previous</button>
              )}
              <button className="button button-primary button-sm" onClick={onTourNext} type="button">
                {tourStep < tourSteps.length - 1 ? "Next" : "Done"}
              </button>
              {tourStep < tourSteps.length - 1 && (
                <button className="button button-ghost button-sm" onClick={onTourDismiss} type="button">Skip</button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ── Portfolio summary with performance surface ── */}
      <div className={`pq-grid ${highlightId === "pq-summary" || highlightId === "pq-rail" ? "pq-grid-has-highlight" : ""}`}>
        <div className={`pq-main ${highlightId === "pq-summary" ? "pq-highlight-child" : ""}`} id="pq-summary">
          <section className="pq-summary">
            <div className="pq-summary-head">
              <div>
                <span className="section-kicker">Your portfolio</span>
                <h2>{recommendation.title}</h2>
              </div>
              {authenticated ? (
                <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                  <button className="button button-primary" onClick={() => setBuyModalOpen(true)} style={{ fontSize: "0.85rem", minHeight: "36px", padding: "0 14px" }} type="button">
                    Buy with 1inch
                  </button>
                  <span style={{ padding: "4px 12px", background: "var(--black)", color: "var(--positive)", border: "2px solid var(--positive)", fontFamily: "var(--font-mono)", fontSize: "0.82rem", fontWeight: 700, letterSpacing: "0.04em" }}>{shortWallet}</span>
                </div>
              ) : (
                <button
                  className="button button-primary button-lg"
                  disabled={!privyEnabled}
                  onClick={privyEnabled ? login : undefined}
                  type="button"
                >
                  {privyEnabled
                    ? directionalPreviewOnly
                      ? "Preview"
                      : "Start deposit"
                    : "Wallet connect unavailable"}
                </button>
              )}
            </div>

            {/* Performance surface with hover */}
            <div className="pq-perf-surface">
              <div className="pq-perf-value">
                <span className="section-kicker">Simulated value</span>
                <strong className="pq-perf-amount">
                  {chartHover ? formatCurrency(chartHover.value) : formatCurrency(manifest.replay.endingCapital)}
                </strong>
                <span className="pq-perf-change pq-perf-change-positive">
                  {chartHover
                    ? formatPercent(((chartHover.value - manifest.replay.startingCapital) / manifest.replay.startingCapital) * 100)
                    : formatPercent(manifest.replay.netReturnPct)}
                </span>
              </div>
              <div
                className="pq-chart-shell"
                onMouseMove={(e) => {
                  const rect = e.currentTarget.getBoundingClientRect();
                  const xPct = (e.clientX - rect.left) / rect.width;
                  const idx = Math.min(Math.round(xPct * (values.length - 1)), values.length - 1);
                  setChartHover({ x: xPct * 100, value: values[idx] });
                }}
                onMouseLeave={() => setChartHover(null)}
              >
                <svg className="workspace-chart" viewBox="0 -5 100 110" preserveAspectRatio="none">
                  <defs>
                    {manifest.allocations.map((alloc, i) => {
                      const colors = ["#ff1800", "#0a0a0a", "#ffd84d", "#39d5ff", "#5ae15a", "#999"];
                      return (
                        <linearGradient key={alloc.symbol} id={`area-${i}`} x1="0%" x2="0%" y1="0%" y2="100%">
                          <stop offset="0%" stopColor={colors[i % colors.length]} stopOpacity="0.6" />
                          <stop offset="100%" stopColor={colors[i % colors.length]} stopOpacity="0.1" />
                        </linearGradient>
                      );
                    })}
                  </defs>
                  {(() => {
                    const weights = manifest.allocations.map(a => parseFloat(a.targetWeight) || 0);
                    const totalWeight = weights.reduce((s, w) => s + w, 0) || 1;
                    const normWeights = weights.map(w => w / totalWeight);
                    const min = Math.min(...values);
                    const max = Math.max(...values);
                    const isFlat = max === min;
                    const range = max - min || 1;
                    const colors = ["#ff1800", "#0a0a0a", "#ffd84d", "#39d5ff", "#5ae15a", "#999"];

                    // Build cumulative stacked areas from bottom to top
                    return manifest.allocations.map((alloc, allocIdx) => {
                      const belowPct = normWeights.slice(0, allocIdx).reduce((s, w) => s + w, 0);
                      const thisPct = normWeights[allocIdx];

                      const topPoints = values.map((v, j) => {
                        const x = (j / Math.max(values.length - 1, 1)) * 100;
                        // When flat, show allocations as horizontal bands filling the chart
                        const y = isFlat
                          ? (1 - (belowPct + thisPct)) * 100
                          : 100 - (((v - min) / range) * (belowPct + thisPct)) * 100;
                        return `${x.toFixed(2)} ${y.toFixed(2)}`;
                      });

                      const bottomPoints = values.map((v, j) => {
                        const x = (j / Math.max(values.length - 1, 1)) * 100;
                        const y = isFlat
                          ? (1 - belowPct) * 100
                          : 100 - (((v - min) / range) * belowPct) * 100;
                        return `${x.toFixed(2)} ${y.toFixed(2)}`;
                      }).reverse();

                      const d = `M ${topPoints.join(" L ")} L ${bottomPoints.join(" L ")} Z`;

                      return (
                        <path
                          key={alloc.symbol}
                          d={d}
                          fill={`url(#area-${allocIdx})`}
                          stroke={colors[allocIdx % colors.length]}
                          strokeWidth="0.5"
                          vectorEffect="non-scaling-stroke"
                        />
                      );
                    }).reverse();
                  })()}
                </svg>
                {chartHover && (
                  <div className="pq-chart-cursor" style={{ left: `${chartHover.x}%` }} />
                )}
              </div>
              <div className="pq-perf-meta">
                <span>30-day simulated replay from {formatCurrency(manifest.replay.startingCapital)}</span>
                <span>Max drawdown: {formatPercent(manifest.replay.maxDrawdownPct)}</span>
              </div>

              {/* Asset allocation bar */}
              <div className="pq-alloc-bar">
                {manifest.allocations.map((alloc, i) => {
                  const weight = parseFloat(alloc.targetWeight) || 0;
                  const colors = ["#ff1800", "#0a0a0a", "#ffd84d", "#39d5ff", "#5ae15a", "#999"];
                  return (
                    <div
                      key={alloc.symbol}
                      className="pq-alloc-segment"
                      style={{ flex: weight, background: colors[i % colors.length] }}
                      title={`${alloc.symbol}: ${alloc.targetWeight}`}
                    />
                  );
                })}
              </div>
              <div className="pq-alloc-legend">
                {manifest.allocations.map((alloc, i) => {
                  const colors = ["#ff1800", "#0a0a0a", "#ffd84d", "#39d5ff", "#5ae15a", "#999"];
                  return (
                    <span className="pq-alloc-legend-item" key={alloc.symbol}>
                      <span className="pq-alloc-legend-dot" style={{ background: colors[i % colors.length] }} />
                      {alloc.symbol} {alloc.targetWeight}
                    </span>
                  );
                })}
              </div>
            </div>

            <div className="pq-summary-strip">
              <div><span>Holdings</span><strong>{manifest.allocations.length}</strong></div>
              <div><span>Risk</span><strong>{manifest.frontend.risk_label}</strong></div>
              <div><span>Rebalance</span><strong>{recommendation.rebalance_cadence.replaceAll("_", " ")}</strong></div>
              <div className="hover-card-trigger">
                <span>Optimisation</span><strong>Autoresearch</strong>
                <span className="hover-card">
                  <strong className="hover-card-title">How Autoresearch works</strong>
                  <p>Automatically tests different portfolio configurations against historical market data and picks the best performer for you.</p>
                  <p>Inspired by Andrej Karpathy&apos;s approach to training neural networks — run many experiments, keep the winner.</p>
                  <p>Your portfolio is the current champion from the latest evaluation cycle. Re-evaluated regularly so it stays competitive.</p>
                </span>
              </div>
            </div>

            <div className="pq-summary-explain">
              <article className="panel-card panel-card-subtle">
                <span className="section-kicker">Why this fits you</span>
                <div className="pq-summary-list">
                  {qualification.whyRecommended.slice(0, 3).map((reason) => (
                    <div className="pq-summary-list-item" key={reason}>
                      <strong>{reason}</strong>
                    </div>
                  ))}
                </div>
              </article>

              <article className="panel-card panel-card-subtle">
                <span className="section-kicker">What changes next</span>
                <div className="info-stack">
                  <div>
                    <span>How it changes</span>
                    <strong>{bundle.howItChanges}</strong>
                  </div>
                  <div>
                    <span>Rebalance trigger</span>
                    <strong>{bundle.whatWouldTriggerNextRebalance}</strong>
                  </div>
                </div>
              </article>
            </div>

            <p className="panel-note">{bundle.howToReadReplay.replace(/basket\.\w+/g, "the benchmark").replace(/_/g, " ")}</p>
          </section>

        </div>

        {/* ── Right rail: market signals ── */}
        <aside className={`pq-rail ${highlightId === "pq-rail" ? "pq-highlight-child" : ""}`} id="pq-rail">
          <section className="pq-rail-card">
            <span className="section-kicker">Market signals</span>
            <h3>{mi.currentView}</h3>
            <span className="pq-mi-updated">Horizon: {mi.horizon}</span>
          </section>

          <section className="pq-rail-card">
            <span className="section-kicker">Drivers</span>
            <div className="pq-drivers">
              {mi.drivers.map((driver) => (
                <div className="pq-driver" key={driver.label}>
                  <span className={`pq-driver-dot pq-driver-dot-${driver.tone}`} />
                  <strong>{driver.label}</strong>
                </div>
              ))}
            </div>
          </section>

          <section className="pq-rail-card">
            <span className="section-kicker">Recent changes</span>
            <ul className="pq-changes-list">
              {mi.whatChanged.slice(0, 2).map((c) => (
                <li key={c}>{c.length > 60 ? c.slice(0, 57) + "..." : c}</li>
              ))}
            </ul>
          </section>
        </aside>
      </div>

      {/* ── Holdings — full-width ── */}
      <section className={`pq-fw-section ${highlightId === "pq-holdings" ? "pq-highlight" : ""}`} id="pq-holdings">
        <div className="pq-fw-inner">
          <span className="section-kicker">Holdings · {manifest.allocations.length} assets</span>
          <p className="panel-note">{bundle.howItIsBuilt}</p>
          <div style={{ overflowX: "auto" }}>
            <table className="data-table">
              <thead><tr><th>Asset</th><th>Weight</th><th>Role</th></tr></thead>
              <tbody>
                {manifest.allocations.map((row) => {
                  const assetHref = getAssetHref(row.symbol);
                  const assetDesc = getAssetDescription(row.symbol);
                  return (
                    <tr key={`${row.symbol}-${row.sleeve}`}>
                      <td>{assetHref ? <a className="table-link" href={assetHref} target="_blank" rel="noopener noreferrer" title={assetDesc ?? undefined}>{row.symbol}</a> : <strong title={assetDesc ?? undefined}>{row.symbol}</strong>}</td>
                      <td>{row.targetWeight}</td>
                      <td>{getCleanRationale(row.rationale, row.sleeve)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* ── Activity — full-width ── */}
      <section className={`pq-fw-section pq-fw-section-alt ${highlightId === "pq-activity-section" ? "pq-highlight" : ""}`} id="pq-activity-section">
        <div className="pq-fw-inner">
          <div className="pq-activity-header">
            <span className="section-kicker">Preview activity</span>
            <span className="preview-chip">Simulation</span>
          </div>
          <div className="pq-activity-grid">
            <div className="pq-activity-col">
              <span className="section-kicker">Positions</span>
              {positions.length > 0 ? (() => {
                const totalUsd = positions.reduce((sum, r) => sum + parseFloat(r.exposureUsd.replace(/[$,]/g, "") || "0"), 0);
                return (
                  <div style={{ overflowX: "auto" }}>
                    <table className="data-table">
                      <thead><tr><th>Symbol</th><th>Value</th><th>Weight</th><th>Status</th></tr></thead>
                      <tbody>
                        {positions.slice(0, 6).map((row) => {
                          const usd = parseFloat(row.exposureUsd.replace(/[$,]/g, "") || "0");
                          const pct = totalUsd > 0 ? ((usd / totalUsd) * 100).toFixed(1) : "—";
                          return (
                            <tr key={row.id}>
                              <td>{row.symbol}</td>
                              <td>{row.exposureUsd}</td>
                              <td>{pct}%</td>
                              <td><span className={`status-pill status-pill-${row.state}`} title={stateTooltip(row.state)}>{humanizeState(row.state)}</span></td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                );
              })() : <p className="panel-note">Positions appear after deposit.</p>}
            </div>
            <div className="pq-activity-col">
              <span className="section-kicker">Events</span>
              {activity.length > 0 ? (
                <div className="pq-events">
                  {activity.slice(0, 6).map((event) => (
                    <div className="pq-event" key={event.id}>
                      <div className="pq-event-meta">
                        <span className="pq-event-time">{event.time}</span>
                        <span className={`status-pill status-pill-${event.state}`} title={stateTooltip(event.state)}>{humanizeState(event.state)}</span>
                      </div>
                      <strong>{event.title}</strong>
                    </div>
                  ))}
                </div>
              ) : <p className="panel-note">Activity appears after deposit.</p>}
            </div>
          </div>
        </div>
      </section>

      {previewStatus && previewStatus.tone === "loading" ? <p className="panel-note" style={{ padding: "16px", textAlign: "center" }}>{previewStatus.message}</p> : null}

      {/* Buy Modal */}
      {buyModalOpen && (
        <div
          className="pq-tour-welcome-overlay"
          role="dialog"
          aria-modal="true"
          aria-label="Buy portfolio"
          onClick={closeBuyModal}
        >
          <div className="pq-tour-welcome-card pq-buy-modal" onClick={(e) => e.stopPropagation()} style={{ maxWidth: "540px", textAlign: "left" }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <h2 id="buy-modal-title" style={{ margin: 0, fontSize: "1.5rem" }}>Buy this portfolio</h2>
              <button
                onClick={closeBuyModal}
                type="button"
                aria-label="Close buy modal"
                style={{ background: "none", border: "none", fontSize: "1.5rem", cursor: "pointer", color: "var(--text-muted)", padding: "4px 8px" }}
              >&times;</button>
            </div>
            <p style={{ margin: 0, color: "var(--text-soft)", fontSize: "0.95rem" }}>Enter the USDC amount. It will be split across the portfolio assets by weight.</p>

            <div style={{ display: "flex", alignItems: "center", gap: "12px", padding: "12px 0" }}>
              <label htmlFor="buy-amount-input" style={{ fontSize: "1.8rem", fontWeight: 700 }}>$</label>
              <input
                id="buy-amount-input"
                type="number"
                inputMode="decimal"
                value={buyAmount}
                onChange={(e) => setBuyAmount(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter" && !buyRunning) void handleBuy(); }}
                aria-label="USDC amount"
                autoFocus
                style={{ flex: 1, fontSize: "1.8rem", fontWeight: 700, border: "var(--border-w) solid var(--black)", padding: "10px 14px", fontFamily: "var(--font-mono)", textAlign: "right" }}
                min="1"
                step="1"
              />
              <span style={{ fontSize: "1rem", color: "var(--text-muted)", fontWeight: 600 }}>USDC</span>
            </div>

            <div style={{ display: "grid", gap: "6px", padding: "12px 0", borderTop: "1px solid var(--gray-200)" }}>
              <span className="section-kicker">Allocation preview</span>
              {manifest.allocations.map((alloc, i) => {
                const weight = parseFloat(alloc.targetWeight) || 0;
                const parsedAmount = parseFloat(buyAmount || "0");
                const amount = Number.isFinite(parsedAmount) && parsedAmount > 0
                  ? ((weight / 100) * parsedAmount).toFixed(2)
                  : "0.00";
                const colors = ["#ff1800", "#0a0a0a", "#ffd84d", "#39d5ff", "#5ae15a", "#999"];
                return (
                  <div key={alloc.symbol} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "6px 0" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                      <span style={{ width: "10px", height: "10px", borderRadius: "2px", background: colors[i % colors.length], flexShrink: 0 }} aria-hidden="true" />
                      <strong style={{ fontSize: "0.95rem" }}>{alloc.symbol}</strong>
                      <span style={{ color: "var(--text-muted)", fontSize: "0.82rem" }}>{alloc.targetWeight}</span>
                    </div>
                    <strong style={{ fontFamily: "var(--font-mono)", fontSize: "0.95rem" }}>${amount}</strong>
                  </div>
                );
              })}
            </div>

            <div style={{ display: "flex", alignItems: "center", gap: "8px", padding: "8px 0", color: "var(--text-muted)", fontSize: "0.82rem" }}>
              <span>Execution via</span>
              <strong style={{ color: "var(--text)" }}>1inch Fusion</strong>
              <span>on</span>
              <strong style={{ color: "var(--text)" }}>Ethereum</strong>
            </div>

            {buyStatus && (
              <div role="status" aria-live="polite" style={{ padding: "10px 14px", background: "var(--gray-100)", border: "1px solid var(--border)", fontSize: "0.88rem", color: "var(--text-soft)" }}>
                {buyStatus}
              </div>
            )}

            <button
              className="button button-primary button-xl"
              style={{ width: "100%", opacity: buyRunning ? 0.6 : 1 }}
              type="button"
              disabled={buyRunning || parseBuyAmount() <= 0}
              onClick={handleBuy}
            >
              {buyRunning ? "Executing..." : !authenticated ? "Connect wallet to buy" : `Buy $${buyAmount} of ${recommendation.title}`}
            </button>

            <p style={{ margin: 0, color: "var(--text-muted)", fontSize: "0.78rem", textAlign: "center" }}>
              You will sign each trade with your connected wallet. Nothing executes without your approval.
            </p>
          </div>
        </div>
      )}

      {/* Infrastructure strip — moved from portfolio section */}
      <section className="pq-fw-section" style={{ marginTop: 0 }}>
        <div className="pq-fw-inner" style={{ maxWidth: 1400, margin: "0 auto" }}>
          <div className="pq-how-row">
            <div><span className="section-kicker">Rebalance</span><strong>Chainlink CRE</strong></div>
            <div><span className="section-kicker">Custody</span><strong>Privy smart wallet</strong></div>
            <div><span className="section-kicker">Execution</span><strong>CoW Protocol + 1inch</strong></div>
          </div>
        </div>
      </section>

      {/* Footer — matches landing page */}
      <footer className="landing-footer">
        <div className="landing-footer-inner">
          <div className="landing-footer-brand-block">
            <BrandLockup size="md" />
            <span className="landing-footer-powered">Powered by xStocks</span>
            <span className="landing-footer-desc">Tokenized equity portfolios trading 24/7.</span>
          </div>
          <div className="landing-footer-col">
            <strong>Product</strong>
            <Link href="/onboarding">Find my portfolio</Link>
            <Link href="/#how-it-works">How it works</Link>
            <Link href="/docs">Documentation</Link>
            <Link href="/#faq">FAQ</Link>
          </div>
          <div className="landing-footer-col">
            <strong>Infrastructure</strong>
            <a href="https://xstocks.fi" target="_blank" rel="noopener noreferrer">xStocks</a>
            <a href="https://privy.io" target="_blank" rel="noopener noreferrer">Privy</a>
            <a href="https://cow.fi" target="_blank" rel="noopener noreferrer">CoW Protocol</a>
            <a href="https://1inch.io" target="_blank" rel="noopener noreferrer">1inch</a>
            <a href="https://chain.link" target="_blank" rel="noopener noreferrer">Chainlink CRE</a>
          </div>
          <div className="landing-footer-col">
            <strong>Open Source</strong>
            <a href="https://github.com/twentyOne2x/xstocks-strategy-lab" target="_blank" rel="noopener noreferrer">GitHub</a>
          </div>
        </div>
      </footer>
    </div>
    </>
  );
}
